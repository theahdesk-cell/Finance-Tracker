
import React, { useState, useEffect } from 'react';
import { Transaction, TransactionType, ViewType, UserProfile } from './types';
import { STORAGE_KEY, SETTINGS_STORAGE_KEY, PROFILE_STORAGE_KEY } from './constants';
import Dashboard from './components/Dashboard';
import History from './components/History';
import Summary from './components/Summary';
import Settings from './components/Settings';
import TransactionForm from './components/TransactionForm';
import DeleteConfirmationModal from './components/DeleteConfirmationModal';

const App: React.FC = () => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [currentView, setCurrentView] = useState<ViewType>('dashboard');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [formType, setFormType] = useState<TransactionType>('EXPENSE');
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [deletingTransactionId, setDeletingTransactionId] = useState<string | null>(null);
  const [savingsGoal, setSavingsGoal] = useState<number>(0);
  const [isFabMenuOpen, setIsFabMenuOpen] = useState(false);
  
  const [profile, setProfile] = useState<UserProfile>({
    name: 'Finance Tracker User',
    phone: '',
    email: '',
    website: 'https://www.coreprompting.com/',
  });

  useEffect(() => {
    const storedTransactions = localStorage.getItem(STORAGE_KEY);
    if (storedTransactions) try { setTransactions(JSON.parse(storedTransactions)); } catch (e) {}
    
    const storedSettings = localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (storedSettings) try { 
      const settings = JSON.parse(storedSettings);
      if (settings.savingsGoal) setSavingsGoal(settings.savingsGoal);
    } catch (e) {}

    const storedProfile = localStorage.getItem(PROFILE_STORAGE_KEY);
    if (storedProfile) try { setProfile(JSON.parse(storedProfile)); } catch (e) {}
  }, []);

  useEffect(() => { localStorage.setItem(STORAGE_KEY, JSON.stringify(transactions)); }, [transactions]);
  useEffect(() => { localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify({ savingsGoal })); }, [savingsGoal]);
  useEffect(() => { localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(profile)); }, [profile]);

  const handleAddTransaction = (type: TransactionType) => {
    setFormType(type);
    setEditingTransaction(null);
    setIsFormOpen(true);
    setIsFabMenuOpen(false);
  };

  const handleEditTransaction = (transaction: Transaction) => {
    setFormType(transaction.type);
    setEditingTransaction(transaction);
    setIsFormOpen(true);
  };

  const handleSaveTransaction = (transaction: Transaction) => {
    if (editingTransaction) {
      setTransactions(prev => prev.map(t => t.id === transaction.id ? transaction : t));
    } else {
      setTransactions(prev => [transaction, ...prev]);
    }
    setIsFormOpen(false);
    setEditingTransaction(null);
  };

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard transactions={transactions} savingsGoal={savingsGoal} onAddTransaction={handleAddTransaction} onEditTransaction={handleEditTransaction} onDeleteTransaction={setDeletingTransactionId} onSeeAll={() => setCurrentView('history')} />;
      case 'history':
        return <History transactions={transactions} onEdit={handleEditTransaction} onDelete={setDeletingTransactionId} />;
      case 'summary':
        return <Summary transactions={transactions} />;
      case 'settings':
        return <Settings profile={profile} setProfile={setProfile} savingsGoal={savingsGoal} setSavingsGoal={setSavingsGoal} transactions={transactions} setTransactions={setTransactions} />;
      default: return null;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-[#006a4e]/20">
      <div className="max-w-lg mx-auto bg-white min-h-screen shadow-2xl relative flex flex-col">
        
        <header className="sticky top-0 z-[110] bg-white/90 backdrop-blur-xl border-b border-slate-50 px-5 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#006a4e] to-[#059669] rounded-xl flex items-center justify-center shadow-lg shadow-emerald-100">
                <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              </div>
              <h1 className="text-lg font-black text-slate-900 tracking-tighter">Finance <span className="text-[#006a4e]">Tracker</span></h1>
            </div>
            <a href="https://Facebook.com/dealsbdonline" target="_blank" className="text-[10px] font-black text-[#f42a41] bg-rose-50 px-3 py-1.5 rounded-full uppercase tracking-widest transition-all active:scale-95">@Deals BD</a>
          </div>
        </header>
        
        <main className="flex-1 overflow-y-auto px-5 pt-6 pb-32">
          {renderView()}
        </main>

        {isFabMenuOpen && <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[115] animate-in fade-in" onClick={() => setIsFabMenuOpen(false)}></div>}

        <div className={`fixed bottom-28 left-1/2 -translate-x-1/2 z-[120] flex flex-col items-center space-y-4 transition-all duration-300 ${isFabMenuOpen ? 'translate-y-0 opacity-100 scale-100' : 'translate-y-20 opacity-0 scale-50 pointer-events-none'}`}>
          <button onClick={() => handleAddTransaction('INCOME')} className="flex flex-col items-center group">
            <div className="w-14 h-14 bg-emerald-500 rounded-full flex items-center justify-center text-white shadow-2xl active:scale-90 transition-all border-4 border-white"><svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 10l7-7m0 0l7 7m-7-7v18" /></svg></div>
            <span className="mt-2 text-[9px] font-black text-white bg-emerald-600 px-3 py-1 rounded-lg uppercase tracking-widest shadow-lg">Income</span>
          </button>
          <button onClick={() => handleAddTransaction('EXPENSE')} className="flex flex-col items-center group">
            <div className="w-14 h-14 bg-rose-500 rounded-full flex items-center justify-center text-white shadow-2xl active:scale-90 transition-all border-4 border-white"><svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M19 14l-7 7m0 0l-7-7m7 7V3" /></svg></div>
            <span className="mt-2 text-[9px] font-black text-white bg-rose-600 px-3 py-1 rounded-lg uppercase tracking-widest shadow-lg">Expense</span>
          </button>
        </div>

        <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-lg bg-white/95 backdrop-blur-2xl border-t border-slate-100 flex justify-between items-center py-4 px-6 z-[118] rounded-t-[40px] shadow-[0_-20px_50px_-20px_rgba(0,0,0,0.2)]">
          <div className="flex w-1/2 justify-around pr-6">
            <NavButton active={currentView === 'dashboard'} onClick={() => setCurrentView('dashboard')} icon={<svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>} label="Home" />
            <NavButton active={currentView === 'history'} onClick={() => setCurrentView('history')} icon={<svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>} label="Logs" />
          </div>

          <div className="absolute left-1/2 -translate-x-1/2 -top-8">
            <button onClick={() => setIsFabMenuOpen(!isFabMenuOpen)} className={`w-18 h-18 rounded-full flex items-center justify-center text-white shadow-[0_15px_30px_-5px_rgba(0,106,78,0.4),inset_0_2px_4px_rgba(255,255,255,0.4)] bg-gradient-to-br from-[#006a4e] to-[#059669] active:scale-95 transition-all duration-500 border-4 border-white ${isFabMenuOpen ? 'rotate-45 bg-slate-900 from-slate-800' : ''}`}>
              <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={4} d="M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg>
            </button>
          </div>

          <div className="flex w-1/2 justify-around pl-6">
            <NavButton active={currentView === 'summary'} onClick={() => setCurrentView('summary')} icon={<svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 002 2h2a2 2 0 002-2z" /></svg>} label="Stats" />
            <NavButton active={currentView === 'settings'} onClick={() => setCurrentView('settings')} icon={<svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0" /></svg>} label="Setup" />
          </div>
        </nav>

        {isFormOpen && <TransactionForm type={formType} editingTransaction={editingTransaction} onSave={handleSaveTransaction} onCancel={() => setIsFormOpen(false)} />}
        {deletingTransactionId && <DeleteConfirmationModal onConfirm={() => { setTransactions(t => t.filter(x => x.id !== deletingTransactionId)); setDeletingTransactionId(null); }} onCancel={() => setDeletingTransactionId(null)} />}
      </div>
    </div>
  );
};

const NavButton = ({ active, onClick, icon, label }: any) => (
  <button onClick={onClick} className={`flex flex-col items-center justify-center space-y-1 ${active ? 'text-[#006a4e]' : 'text-slate-400'}`}>
    <div className={`p-1.5 rounded-xl ${active ? 'bg-emerald-50' : ''}`}>{icon}</div>
    <span className="text-[8px] font-black uppercase tracking-widest">{label}</span>
  </button>
);

export default App;

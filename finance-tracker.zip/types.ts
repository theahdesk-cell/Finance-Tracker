
export type TransactionType = 'INCOME' | 'EXPENSE';

export enum IncomeSource {
  SALARY = 'Salary',
  BUSINESS = 'Business',
  FREELANCE = 'Freelance',
  OTHER = 'Other'
}

export enum ExpenseCategory {
  FOOD = 'Food',
  WORK = 'Work',
  TRANSPORT = 'Transport',
  RENT = 'Rent',
  SHOPPING = 'Shopping',
  PERSONAL = 'Personal',
  OTHERS = 'Others'
}

export interface Transaction {
  id: string;
  type: TransactionType;
  amount: number;
  category: IncomeSource | ExpenseCategory;
  date: string; // ISO String
  note?: string;
}

export interface UserProfile {
  name: string;
  phone: string;
  email: string;
  website: string;
  facebook?: string;
  linkedin?: string;
  avatar?: string; // Base64 string
  bio?: string;
  address?: string;
}

export interface MonthlyStats {
  totalIncome: number;
  totalExpense: number;
  balance: number;
}

export type ViewType = 'dashboard' | 'history' | 'summary' | 'settings';


import { Transaction, TransactionType } from './types';

export const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-BD', {
    style: 'currency',
    currency: 'BDT',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount).replace('BDT', '৳');
};

export const getStartOfDay = (date: Date = new Date()) => {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  return d;
};

export const getYesterday = () => {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  d.setHours(0, 0, 0, 0);
  return d;
};

export const getLastXDays = (days: number) => {
  const d = new Date();
  d.setDate(d.getDate() - days);
  d.setHours(0, 0, 0, 0);
  return d;
};

export const getStartOfWeek = (date: Date = new Date()) => {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1); // Adjust for Monday start or Sunday
  d.setDate(diff);
  d.setHours(0, 0, 0, 0);
  return d;
};

export const getStartOfMonth = (date: Date = new Date()) => {
  return new Date(date.getFullYear(), date.getMonth(), 1);
};

export const getEndOfMonth = (date: Date = new Date()) => {
  return new Date(date.getFullYear(), date.getMonth() + 1, 0);
};

export const isSameDay = (d1: Date, d2: Date) => {
  return (
    d1.getFullYear() === d2.getFullYear() &&
    d1.getMonth() === d2.getMonth() &&
    d1.getDate() === d2.getDate()
  );
};

export const isSameMonth = (d1: Date, d2: Date) => {
  return (
    d1.getFullYear() === d2.getFullYear() &&
    d1.getMonth() === d2.getMonth()
  );
};

export const generateId = () => Math.random().toString(36).slice(2, 11);

/**
 * Converts transactions array to CSV string
 */
export const convertToCSV = (transactions: Transaction[]): string => {
  const headers = ['ID', 'Type', 'Amount', 'Category', 'Date', 'Note'];
  const rows = transactions.map(t => [
    t.id,
    t.type,
    t.amount,
    t.category,
    t.date,
    t.note || ''
  ]);
  
  return [
    headers.join(','),
    ...rows.map(row => row.map(val => `"${String(val).replace(/"/g, '""')}"`).join(','))
  ].join('\n');
};

/**
 * Parses CSV string back to Transaction objects
 */
export const parseCSV = (csvText: string): Transaction[] => {
  const lines = csvText.trim().split('\n');
  if (lines.length < 2) return [];

  const headers = lines[0].split(',').map(h => h.replace(/"/g, '').trim().toUpperCase());
  const transactions: Transaction[] = [];

  for (let i = 1; i < lines.length; i++) {
    // Basic CSV splitting that handles quoted values
    const values = lines[i].match(/(".*?"|[^",\s]+)(?=\s*,|\s*$)/g);
    if (!values || values.length < headers.length) continue;

    const row: any = {};
    headers.forEach((header, index) => {
      row[header] = values[index].replace(/^"|"$/g, '').replace(/""/g, '"').trim();
    });

    // Validate and build object
    if (row.ID && row.TYPE && row.AMOUNT && row.CATEGORY && row.DATE) {
      transactions.push({
        id: row.ID || generateId(),
        type: (row.TYPE === 'INCOME' ? 'INCOME' : 'EXPENSE') as TransactionType,
        amount: parseFloat(row.AMOUNT) || 0,
        category: row.CATEGORY,
        date: row.DATE,
        note: row.NOTE || undefined
      });
    }
  }

  return transactions;
};


import React, { useState, useMemo } from 'react';
import { Transaction } from '../types';
import { formatCurrency, getStartOfDay, getYesterday, getLastXDays, getStartOfMonth } from '../utils';

type Timeframe = 'ALL' | 'TODAY' | 'YESTERDAY' | 'WEEK' | 'MONTH' | 'LAST30';
type TypeFilter = 'ALL' | 'INCOME' | 'EXPENSE';

interface HistoryProps {
  transactions: Transaction[];
  onEdit: (transaction: Transaction) => void;
  onDelete: (id: string) => void;
}

const History: React.FC<HistoryProps> = ({ transactions, onEdit, onDelete }) => {
  const [typeFilter, setTypeFilter] = useState<TypeFilter>('ALL');
  const [timeframe, setTimeframe] = useState<Timeframe>('ALL');
  const [search, setSearch] = useState('');

  const timeframes: { label: string; value: Timeframe }[] = [
    { label: 'All Time', value: 'ALL' },
    { label: 'Today', value: 'TODAY' },
    { label: 'Yesterday', value: 'YESTERDAY' },
    { label: 'Last 7 Days', value: 'WEEK' },
    { label: 'Last 30 Days', value: 'LAST30' },
    { label: 'This Month', value: 'MONTH' },
  ];

  const filteredTransactions = useMemo(() => {
    const now = new Date();
    const startOfToday = getStartOfDay(now).getTime();
    const startOfYesterday = getYesterday().getTime();
    const startOfLast7Days = getLastXDays(7).getTime();
    const startOfLast30Days = getLastXDays(30).getTime();
    const startOfThisMonth = getStartOfMonth(now).getTime();

    return transactions
      .filter(t => {
        // Type Filter
        if (typeFilter !== 'ALL' && t.type !== typeFilter) return false;
        
        // Search Filter
        const searchLower = search.toLowerCase();
        const matchesSearch = 
          t.category.toLowerCase().includes(searchLower) || 
          (t.note?.toLowerCase().includes(searchLower) ?? false);
        if (search && !matchesSearch) return false;

        // Timeframe Filter
        const tDate = new Date(t.date).getTime();
        if (timeframe === 'TODAY' && tDate < startOfToday) return false;
        if (timeframe === 'YESTERDAY') {
          if (tDate < startOfYesterday || tDate >= startOfToday) return false;
        }
        if (timeframe === 'WEEK' && tDate < startOfLast7Days) return false;
        if (timeframe === 'LAST30' && tDate < startOfLast30Days) return false;
        if (timeframe === 'MONTH' && tDate < startOfThisMonth) return false;
        
        return true;
      })
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [transactions, typeFilter, timeframe, search]);

  const stats = useMemo(() => {
    return filteredTransactions.reduce((acc, t) => {
      if (t.type === 'INCOME') acc.income += t.amount;
      else acc.expense += t.amount;
      return acc;
    }, { income: 0, expense: 0 });
  }, [filteredTransactions]);

  return (
    <div className="space-y-4 pb-20">
      <header className="px-1 space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-black text-slate-900 tracking-tight">Activity Log</h1>
          <div className="flex items-center space-x-1 px-2.5 py-1 bg-slate-50 rounded-full">
            <span className="w-1 h-1 bg-emerald-500 rounded-full animate-pulse"></span>
            <span className="text-[7px] font-black text-slate-400 uppercase tracking-widest">{filteredTransactions.length} records</span>
          </div>
        </div>
        
        <div className="space-y-3">
          {/* Search Box */}
          <div className="relative">
            <svg className="w-3.5 h-3.5 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <input 
              type="text" 
              placeholder="Search category or memo..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-white border border-slate-100 rounded-2xl text-[11px] font-black text-slate-800 placeholder:text-slate-300 focus:ring-1 focus:ring-[#006a4e]/20 focus:border-[#006a4e]/30 shadow-sm outline-none transition-all"
            />
          </div>

          {/* Type Toggle */}
          <div className="flex bg-slate-100/80 p-1 rounded-2xl">
            {(['ALL', 'INCOME', 'EXPENSE'] as const).map((type) => (
              <button
                key={type}
                onClick={() => setTypeFilter(type)}
                className={`flex-1 py-2 text-[8px] font-black rounded-xl transition-all uppercase tracking-widest ${
                  typeFilter === type ? 'bg-white text-[#006a4e] shadow-sm' : 'text-slate-400 hover:text-slate-600'
                }`}
              >
                {type}
              </button>
            ))}
          </div>

          {/* Timeframe Scroll */}
          <div className="flex overflow-x-auto gap-2 pb-1 hide-scrollbar scroll-smooth">
            {timeframes.map((tf) => (
              <button
                key={tf.value}
                onClick={() => setTimeframe(tf.value)}
                className={`flex-shrink-0 px-4 py-1.5 rounded-full text-[8px] font-black uppercase tracking-widest border transition-all ${
                  timeframe === tf.value 
                  ? 'bg-[#006a4e] border-[#006a4e] text-white shadow-md' 
                  : 'bg-white border-slate-100 text-slate-400 hover:border-slate-200'
                }`}
              >
                {tf.label}
              </button>
            ))}
          </div>
        </div>
      </header>

      {/* Quick Summary Bar */}
      {filteredTransactions.length > 0 && (
        <div className="grid grid-cols-2 gap-2 px-1">
          <div className="bg-emerald-50/50 rounded-2xl p-2.5 border border-emerald-100/50">
            <p className="text-[7px] font-black text-emerald-600 uppercase tracking-widest mb-1">Total Received</p>
            <p className="text-sm font-black text-emerald-700">{formatCurrency(stats.income)}</p>
          </div>
          <div className="bg-rose-50/50 rounded-2xl p-2.5 border border-rose-100/50">
            <p className="text-[7px] font-black text-rose-600 uppercase tracking-widest mb-1">Total Spent</p>
            <p className="text-sm font-black text-rose-700">{formatCurrency(stats.expense)}</p>
          </div>
        </div>
      )}

      {/* List */}
      <div className="space-y-2.5 px-1">
        {filteredTransactions.length === 0 ? (
          <div className="text-center py-20 flex flex-col items-center justify-center bg-white border border-dashed border-slate-200 rounded-[32px] space-y-3">
            <div className="w-12 h-12 bg-slate-50 rounded-full flex items-center justify-center text-xl">🔍</div>
            <div>
              <p className="text-slate-900 text-[11px] font-black uppercase tracking-widest">No matching records</p>
              <p className="text-slate-400 text-[8px] font-bold uppercase tracking-widest mt-1">Try adjusting your filters</p>
            </div>
            <button 
              onClick={() => { setTypeFilter('ALL'); setTimeframe('ALL'); setSearch(''); }}
              className="text-[9px] font-black text-[#006a4e] uppercase tracking-widest px-4 py-2 bg-emerald-50 rounded-xl hover:bg-emerald-100"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          filteredTransactions.map((t) => (
            <div 
              key={t.id} 
              onClick={() => onEdit(t)}
              className="group relative bg-white p-3.5 rounded-[22px] flex items-center justify-between border border-slate-100 shadow-sm active:scale-[0.98] transition-all cursor-pointer hover:border-[#006a4e]/10 overflow-hidden"
            >
              <div className={`absolute left-0 top-0 bottom-0 w-1.5 ${
                t.type === 'INCOME' ? 'bg-emerald-500' : 'bg-[#f42a41]'
              }`}></div>
              
              <div className="flex items-center space-x-4 pl-1">
                <div className={`w-10 h-10 rounded-2xl flex items-center justify-center text-lg ${
                  t.type === 'INCOME' ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'
                }`}>
                  {t.type === 'INCOME' ? '💸' : '🛒'}
                </div>
                <div>
                  <p className="font-black text-slate-800 text-[13px] leading-tight tracking-tight">{t.category}</p>
                  <div className="flex items-center space-x-2 mt-1.5">
                    <p className="text-[7px] text-slate-400 font-black uppercase tracking-[0.15em]">
                      {new Date(t.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
                    </p>
                    {t.note && (
                      <>
                        <span className="w-0.5 h-0.5 bg-slate-200 rounded-full"></span>
                        <p className="text-[7px] text-slate-300 font-black italic truncate max-w-[120px]">{t.note}</p>
                      </>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-3 pr-1">
                <div className="text-right">
                  <p className={`font-black text-[14px] tracking-tighter ${
                    t.type === 'INCOME' ? 'text-emerald-600' : 'text-rose-600'
                  }`}>
                    {t.type === 'INCOME' ? '+' : '-'}{formatCurrency(t.amount)}
                  </p>
                </div>
                <button 
                  onClick={(e) => { e.stopPropagation(); onDelete(t.id); }}
                  className="p-1.5 text-slate-200 hover:text-rose-500 transition-colors bg-slate-50 rounded-lg group-hover:text-slate-300"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default History;


import React from 'react';

const NewsletterBanner: React.FC = () => {
  return (
    <div className="relative group mt-6 mb-8">
      <a 
        href="https://www.coreprompting.com/newsletter/" 
        target="_blank" 
        rel="noopener noreferrer"
        className="relative block"
      >
        <div className="relative flex items-center justify-between bg-white border border-slate-100 rounded-xl px-3 py-1.5 shadow-sm transition-all duration-300 hover:border-emerald-200 hover:shadow-md active:scale-[0.99] overflow-hidden">
          
          {/* Subtle Shimmer Effect */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-emerald-50/20 to-transparent -translate-x-full group-hover:animate-[shimmer-news_2.5s_infinite]"></div>

          <div className="flex items-center space-x-2.5 z-10 min-w-0">
            {/* Ultra Compact Icon */}
            <div className="flex-shrink-0 w-6 h-6 bg-emerald-50 rounded-lg flex items-center justify-center text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white transition-colors duration-300">
              <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
              </svg>
            </div>

            {/* Typography - Slim & No Truncation */}
            <div className="flex flex-col">
              <p className="text-[11px] font-black text-slate-800 leading-tight">
                প্রয়োজনীয় <span className="text-emerald-600">AI প্রম্পট</span> পেতে সাবস্ক্রাইব করুন।
              </p>
              <p className="text-[7px] font-black text-slate-400 uppercase tracking-widest leading-none mt-0.5">
                Premium AI Newsletter
              </p>
            </div>
          </div>

          {/* Minimalist Action */}
          <div className="z-10 ml-2">
            <div className="bg-slate-900 text-white text-[8px] font-black uppercase tracking-[0.2em] px-3 py-1.5 rounded-md flex items-center group-hover:bg-emerald-600 transition-colors whitespace-nowrap">
              Join
              <svg className="w-2.5 h-2.5 ml-1 transition-transform group-hover:translate-x-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M9 5l7 7-7 7" />
              </svg>
            </div>
          </div>
        </div>
      </a>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes shimmer-news {
          100% { transform: translateX(100%); }
        }
      `}} />
    </div>
  );
};

export default NewsletterBanner;

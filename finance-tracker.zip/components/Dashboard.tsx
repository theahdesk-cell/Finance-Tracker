
import React, { useMemo } from 'react';
import { Transaction } from '../types';
import { formatCurrency, isSameDay, isSameMonth } from '../utils';
import PromoBanner from './PromoBanner';
import NewsletterBanner from './NewsletterBanner';

interface DashboardProps {
  transactions: Transaction[];
  savingsGoal: number;
  onAddTransaction: (type: 'INCOME' | 'EXPENSE') => void;
  onEditTransaction: (transaction: Transaction) => void;
  onDeleteTransaction: (id: string) => void;
  onSeeAll: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ 
  transactions, 
  savingsGoal,
  onAddTransaction, 
  onEditTransaction,
  onDeleteTransaction,
  onSeeAll 
}) => {
  const now = new Date();
  
  // Calculate stats for the current month
  const monthTransactions = transactions.filter(t => isSameMonth(new Date(t.date), now));

  const totals = transactions.reduce((acc, t) => {
    if (t.type === 'INCOME') acc.income += t.amount;
    else acc.expense += t.amount;
    return acc;
  }, { income: 0, expense: 0 });

  const monthIncome = monthTransactions.filter(t => t.type === 'INCOME').reduce((sum, t) => sum + t.amount, 0);
  const monthExpense = monthTransactions.filter(t => t.type === 'EXPENSE').reduce((sum, t) => sum + t.amount, 0);
  const monthSavings = Math.max(0, monthIncome - monthExpense);

  const currentBalance = totals.income - totals.expense;
  const savingsProgress = savingsGoal > 0 ? Math.min(100, (monthSavings / savingsGoal) * 100) : 0;

  // Robustly sort and slice the last 4 records for a compact view
  const recentActivity = useMemo(() => {
    return [...transactions]
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 4);
  }, [transactions]);

  return (
    <div className="space-y-4 pb-28">
      {/* Premium Balance Card */}
      <div className="relative rounded-[32px] p-6 text-white shadow-2xl overflow-hidden group border border-emerald-800/10">
        <div className="absolute inset-0 bg-[#006a4e]"></div>
        <div className="absolute -top-12 -right-12 w-48 h-48 bg-emerald-400/20 rounded-full blur-[60px] animate-pulse"></div>
        <div className="absolute -bottom-12 -left-12 w-48 h-48 bg-[#f42a41]/10 rounded-full blur-[60px]"></div>

        <div className="relative z-10">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2">
              <span className="h-2 w-2 rounded-full bg-emerald-300 animate-pulse"></span>
              <p className="text-emerald-50/70 text-[8px] font-black uppercase tracking-[0.25em]">Account Balance</p>
            </div>
            <div className="bg-white/15 backdrop-blur-md rounded-lg px-2 py-0.5 border border-white/10">
               <span className="text-[7px] font-black uppercase text-white/90">BDT Tracker</span>
            </div>
          </div>
          
          <div className="mb-5">
            <h1 className="text-5xl font-black tracking-tighter flex items-baseline leading-none">
              <span className="text-emerald-300 text-2xl font-bold mr-2">৳</span>
              <span className="bg-clip-text text-transparent bg-gradient-to-b from-white to-emerald-50">
                {currentBalance.toLocaleString('en-BD')}
              </span>
            </h1>
          </div>
          
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-3">
              <p className="text-emerald-100/50 text-[7px] font-black uppercase mb-1 tracking-widest">Income</p>
              <p className="text-white text-sm font-black leading-none">{formatCurrency(monthIncome)}</p>
            </div>
            <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-3">
              <p className="text-emerald-100/50 text-[7px] font-black uppercase mb-1 tracking-widest">Spent</p>
              <p className="text-white text-sm font-black leading-none">{formatCurrency(monthExpense)}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Primary Action Suite */}
      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={() => onAddTransaction('INCOME')}
          className="group relative flex items-center justify-center space-x-2.5 bg-[#006a4e] text-white py-3.5 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl active:scale-95 transition-all overflow-hidden"
        >
          <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
          <div className="w-6 h-6 bg-white/20 rounded-lg flex items-center justify-center">
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={4} d="M12 4v16m8-8H4" /></svg>
          </div>
          <span>Add Income</span>
        </button>
        <button
          onClick={() => onAddTransaction('EXPENSE')}
          className="group relative flex items-center justify-center space-x-2.5 bg-[#f42a41] text-white py-3.5 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl active:scale-95 transition-all overflow-hidden"
        >
          <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
          <div className="w-6 h-6 bg-white/20 rounded-lg flex items-center justify-center">
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={4} d="M20 12H4" /></svg>
          </div>
          <span>Add Expense</span>
        </button>
      </div>

      {/* Savings Metric */}
      {savingsGoal > 0 && (
        <div className="bg-white p-4 rounded-3xl border border-slate-100/80 shadow-[0_4px_20px_-10px_rgba(0,0,0,0.05)] mx-0.5">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <span className="text-xs">🎯</span>
              <p className="text-slate-500 text-[8px] font-black uppercase tracking-[0.15em]">Goal Progress</p>
            </div>
            <span className={`text-[9px] font-black px-2 py-0.5 rounded-full ${savingsProgress >= 100 ? 'bg-emerald-600 text-white shadow-lg' : 'bg-emerald-50 text-emerald-700'}`}>
              {Math.round(savingsProgress)}%
            </span>
          </div>
          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
            <div 
              className={`h-full rounded-full transition-all duration-1000 cubic-bezier(0.16, 1, 0.3, 1) ${savingsProgress >= 100 ? 'bg-emerald-600' : 'bg-[#006a4e]'}`}
              style={{ width: `${savingsProgress}%` }}
            ></div>
          </div>
        </div>
      )}

      <PromoBanner />

      {/* Enhanced Compact Recent Activity Section (Last 4 Records) */}
      <div className="pt-1">
        <div className="flex items-center justify-between mb-3 px-1">
          <div className="flex items-center space-x-2">
            <div className="w-1 h-3 bg-[#006a4e] rounded-full"></div>
            <h2 className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em]">Latest Activity</h2>
          </div>
          <button 
            onClick={onSeeAll} 
            className="text-[8px] font-black text-slate-400 uppercase tracking-widest hover:text-[#006a4e] transition-colors"
          >
            All Records
          </button>
        </div>

        <div className="space-y-2">
          {recentActivity.length > 0 ? (
            recentActivity.map(t => (
              <div 
                key={t.id} 
                onClick={() => onEditTransaction(t)}
                className="group relative bg-white border border-slate-100/80 rounded-2xl p-2.5 flex items-center justify-between shadow-sm active:scale-[0.98] transition-all cursor-pointer hover:border-emerald-100 overflow-hidden"
              >
                {/* Visual Status Bar */}
                <div className={`absolute left-0 top-0 bottom-0 w-1 ${
                  t.type === 'INCOME' ? 'bg-emerald-500' : 'bg-[#f42a41]'
                }`}></div>

                <div className="flex items-center space-x-3 pl-1.5">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center text-base ${
                    t.type === 'INCOME' ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'
                  }`}>
                    {t.type === 'INCOME' ? '💸' : '🛒'}
                  </div>
                  <div>
                    <p className="font-black text-slate-800 text-[12px] leading-none tracking-tight">{t.category}</p>
                    <div className="flex items-center space-x-1.5 mt-1.5">
                      <p className="text-[7px] text-slate-400 font-black uppercase tracking-widest">
                        {new Date(t.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}
                      </p>
                      {t.note && (
                        <>
                          <span className="w-0.5 h-0.5 bg-slate-200 rounded-full"></span>
                          <p className="text-[7px] text-slate-300 font-bold truncate max-w-[120px] italic">{t.note}</p>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-2 pr-1">
                  <p className={`font-black text-[13px] tracking-tighter ${
                    t.type === 'INCOME' ? 'text-emerald-600' : 'text-rose-600'
                  }`}>
                    {t.type === 'INCOME' ? '+' : '-'}{formatCurrency(t.amount)}
                  </p>
                  <div className="text-slate-200">
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M9 5l7 7-7 7" /></svg>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="py-10 flex flex-col items-center justify-center bg-slate-50/50 rounded-2xl border border-dashed border-slate-200">
               <p className="text-slate-300 text-[8px] font-black uppercase tracking-widest">No Activity Yet</p>
            </div>
          )}
        </div>
      </div>

      <NewsletterBanner />
    </div>
  );
};

export default Dashboard;

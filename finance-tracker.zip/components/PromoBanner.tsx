
import React from 'react';

const PromoBanner: React.FC = () => {
  return (
    <div className="relative w-full overflow-hidden mb-3">
      <a 
        href="https://www.coreprompting.com/" 
        target="_blank" 
        rel="noopener noreferrer"
        className="group relative flex items-center justify-between bg-white border border-slate-100 rounded-xl px-3 py-1.5 shadow-sm transition-all active:scale-[0.98] hover:border-emerald-100"
      >
        {/* Animated Background Shimmer */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-emerald-50/40 to-transparent -translate-x-full group-hover:animate-[shimmer-slim_2s_infinite]"></div>

        <div className="flex items-center space-x-2.5 z-10 min-w-0">
          <span className="flex-shrink-0 text-xs animate-pulse">🎁</span>
          <span className="text-[11px] font-black text-slate-700 tracking-tight leading-tight">
            ফ্রি রিসোর্স পেতে <span className="text-emerald-600">ভিসিট করুন।</span>
          </span>
        </div>

        <div className="z-10 ml-2">
          <div className="bg-slate-900 text-white text-[8px] font-black uppercase tracking-[0.2em] px-2.5 py-1 rounded-md flex items-center group-hover:bg-emerald-600 transition-colors">
            Visit
            <svg className="w-2.5 h-2.5 ml-1 transition-transform group-hover:translate-x-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M9 5l7 7-7 7" />
            </svg>
          </div>
        </div>
      </a>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes shimmer-slim {
          100% { transform: translateX(100%); }
        }
      `}} />
    </div>
  );
};

export default PromoBanner;

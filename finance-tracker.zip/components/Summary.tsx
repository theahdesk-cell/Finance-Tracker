
import React, { useMemo } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { Transaction } from '../types';
import { formatCurrency, isSameMonth } from '../utils';
import { EXPENSE_CATEGORIES } from '../constants';

interface SummaryProps {
  transactions: Transaction[];
}

const Summary: React.FC<SummaryProps> = ({ transactions }) => {
  const currentMonth = new Date();
  const monthTransactions = transactions.filter(t => isSameMonth(new Date(t.date), currentMonth));

  const stats = useMemo(() => {
    const expensesByCategory = monthTransactions
      .filter(t => t.type === 'EXPENSE')
      .reduce((acc: Record<string, number>, t) => {
        const categoryKey = String(t.category);
        acc[categoryKey] = (acc[categoryKey] || 0) + t.amount;
        return acc;
      }, {} as Record<string, number>);

    const chartData = Object.entries(expensesByCategory).map(([name, value]) => ({
      name,
      value: value as number,
      color: EXPENSE_CATEGORIES.find(c => c.id === name)?.color || '#94A3B8'
    })).sort((a, b) => (b.value as number) - (a.value as number));

    const totalIncome = monthTransactions.filter(t => t.type === 'INCOME').reduce((sum, t) => sum + t.amount, 0);
    const totalExpense = monthTransactions.filter(t => t.type === 'EXPENSE').reduce((sum, t) => sum + t.amount, 0);

    return { totalIncome, totalExpense, chartData };
  }, [monthTransactions]);

  const monthName = currentMonth.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' });

  return (
    <div className="space-y-6 pb-32">
      <header className="px-1 flex flex-col items-center text-center">
        <h1 className="text-2xl font-black text-slate-800 tracking-tight">Financial Health</h1>
        <p className="text-[10px] font-black text-[#006a4e] uppercase tracking-[0.2em] bg-[#006a4e]/10 px-4 py-1.5 rounded-full mt-2">
          {monthName} Insights
        </p>
      </header>

      {/* Main Stats */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white p-5 rounded-[28px] shadow-sm border border-slate-100 flex flex-col justify-between">
          <div>
            <p className="text-slate-400 text-[9px] font-black uppercase tracking-widest mb-1">Total Savings</p>
            <p className="text-xl font-black text-[#006a4e]">
              {formatCurrency(Math.max(0, stats.totalIncome - stats.totalExpense))}
            </p>
          </div>
          <div className="w-full bg-slate-50 h-1.5 rounded-full mt-4 overflow-hidden">
             <div 
               className="bg-[#006a4e] h-full rounded-full transition-all duration-1000" 
               style={{ width: `${Math.min(100, (stats.totalIncome > 0 ? ((stats.totalIncome - stats.totalExpense) / stats.totalIncome) * 100 : 0))}%` }}
             ></div>
          </div>
        </div>
        <div className="bg-white p-5 rounded-[28px] shadow-sm border border-slate-100 flex flex-col justify-between">
          <div>
            <p className="text-slate-400 text-[9px] font-black uppercase tracking-widest mb-1">Expense Ratio</p>
            <p className="text-xl font-black text-[#f42a41]">
              {stats.totalIncome > 0 ? Math.round((stats.totalExpense / stats.totalIncome) * 100) : 0}%
            </p>
          </div>
          <div className="w-full bg-slate-50 h-1.5 rounded-full mt-4 overflow-hidden">
             <div 
               className="bg-[#f42a41] h-full rounded-full transition-all duration-1000" 
               style={{ width: `${Math.min(100, (stats.totalIncome > 0 ? (stats.totalExpense / stats.totalIncome) * 100 : 0))}%` }}
             ></div>
          </div>
        </div>
      </div>

      {/* Data Visualization Section - Green Theme */}
      <div className="bg-[#006a4e] p-7 rounded-[36px] shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -mr-16 -mt-16 blur-2xl"></div>
        
        <div className="relative z-10">
          <h3 className="text-white/60 text-[9px] font-black uppercase tracking-[0.2em] mb-6">Spending Distribution</h3>
          {stats.chartData.length > 0 ? (
            <div className="h-[240px] w-full relative">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={stats.chartData}
                    cx="50%"
                    cy="50%"
                    innerRadius={65}
                    outerRadius={95}
                    paddingAngle={6}
                    dataKey="value"
                    animationDuration={1500}
                  >
                    {stats.chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} strokeWidth={0} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value: number) => formatCurrency(value)}
                    contentStyle={{ borderRadius: '24px', border: 'none', padding: '12px 16px', fontWeight: '900', fontSize: '12px', boxShadow: '0 20px 40px rgba(0,0,0,0.1)' }}
                  />
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-center pointer-events-none">
                <p className="text-white/40 text-[8px] font-black uppercase tracking-widest leading-none mb-1">Total</p>
                <p className="text-white text-lg font-black leading-none">{formatCurrency(stats.totalExpense)}</p>
              </div>
            </div>
          ) : (
            <div className="h-[200px] flex items-center justify-center">
              <p className="text-white/40 text-xs font-black uppercase tracking-widest italic text-center">No data found</p>
            </div>
          )}
        </div>
      </div>

      {/* Category List */}
      <div className="space-y-3">
        {stats.chartData.map((item) => (
          <div key={item.name} className="flex items-center justify-between p-4 bg-white border border-slate-100 rounded-[24px] transition-all hover:border-[#006a4e]/20">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 rounded-2xl flex items-center justify-center text-lg" style={{ backgroundColor: `${item.color}15`, color: item.color }}>
                 <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></div>
              </div>
              <div>
                <span className="font-black text-slate-700 text-[13px]">{item.name}</span>
                <div className="flex items-center space-x-2 mt-1">
                  <div className="w-16 bg-slate-50 h-1 rounded-full overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: `${Math.round((item.value / stats.totalExpense) * 100)}%`, backgroundColor: item.color }}></div>
                  </div>
                  <span className="text-[9px] text-slate-400 font-bold">{Math.round((item.value / stats.totalExpense) * 100)}%</span>
                </div>
              </div>
            </div>
            <p className="font-black text-slate-900 text-sm">{formatCurrency(item.value)}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Summary;


import React, { useState, useEffect } from 'react';
import { Transaction, TransactionType, IncomeSource, ExpenseCategory } from '../types';
import { INCOME_SOURCES, EXPENSE_CATEGORIES } from '../constants';
import { generateId } from '../utils';

interface TransactionFormProps {
  type: TransactionType;
  editingTransaction: Transaction | null;
  onSave: (transaction: Transaction) => void;
  onCancel: () => void;
}

const TransactionForm: React.FC<TransactionFormProps> = ({ type, editingTransaction, onSave, onCancel }) => {
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState<string>(
    type === 'INCOME' ? IncomeSource.SALARY : ExpenseCategory.FOOD
  );
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [note, setNote] = useState('');

  useEffect(() => {
    if (editingTransaction) {
      setAmount(editingTransaction.amount.toString());
      setCategory(editingTransaction.category);
      setDate(new Date(editingTransaction.date).toISOString().split('T')[0]);
      setNote(editingTransaction.note || '');
    }
  }, [editingTransaction]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || parseFloat(amount) <= 0) return;

    const transactionData: Transaction = {
      id: editingTransaction ? editingTransaction.id : generateId(),
      type,
      amount: parseFloat(amount),
      category: category as any,
      date: new Date(date).toISOString(),
      note: note.trim() || undefined,
    };

    onSave(transactionData);
  };

  const categories = type === 'INCOME' ? INCOME_SOURCES : EXPENSE_CATEGORIES;
  const brandGreen = '#006a4e';
  const brandRed = '#f42a41';
  const accentColor = type === 'INCOME' ? brandGreen : brandRed;
  const lightAccent = type === 'INCOME' ? '#ecfdf5' : '#fff1f2';
  const gradientColor = type === 'INCOME' ? '#059669' : '#e11d48';

  return (
    <div className="fixed inset-0 z-[150] flex items-end sm:items-center justify-center bg-slate-900/60 backdrop-blur-sm p-0 sm:p-4 animate-in fade-in duration-300">
      <div className="bg-white w-full max-w-md rounded-t-[32px] sm:rounded-3xl shadow-2xl overflow-hidden animate-in slide-in-from-bottom-8 duration-500 ease-out">
        
        {/* Visual Handle for Mobile */}
        <div className="flex justify-center pt-3 pb-1 sm:hidden">
          <div className="w-12 h-1 bg-slate-200 rounded-full"></div>
        </div>
        
        <div className="px-6 pb-8 pt-2">
          {/* Professional Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <div 
                className="w-10 h-10 rounded-2xl flex items-center justify-center text-xl shadow-inner"
                style={{ backgroundColor: lightAccent, color: accentColor }}
              >
                {type === 'INCOME' ? '💹' : '📉'}
              </div>
              <div>
                <h2 className="text-[14px] font-black text-slate-900 uppercase tracking-widest leading-none">
                  {editingTransaction ? 'Edit Record' : (type === 'INCOME' ? 'Add Income' : 'Add Expense')}
                </h2>
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] mt-1">
                  Financial Command Center
                </p>
              </div>
            </div>
            <button 
              onClick={onCancel} 
              className="w-8 h-8 flex items-center justify-center rounded-xl bg-slate-50 text-slate-400 hover:bg-slate-100 hover:text-slate-600 active:scale-90 transition-all"
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Compact Vault-Style Amount Entry */}
            <div className="relative group">
              <div className="absolute inset-y-0 left-5 flex items-center pointer-events-none">
                <span className="text-2xl font-black transition-colors" style={{ color: accentColor }}>৳</span>
              </div>
              <input
                type="number"
                inputMode="decimal"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="w-full bg-slate-50 border-2 border-transparent focus:border-slate-100 pl-12 pr-6 py-5 rounded-2xl text-4xl font-black text-slate-900 focus:bg-white transition-all placeholder:text-slate-200 outline-none"
                required
                autoFocus
              />
              <div className="absolute bottom-3 right-5 pointer-events-none">
                <span className="text-[8px] font-black text-slate-300 uppercase tracking-widest">Amount BDT</span>
              </div>
            </div>

            {/* Optimized Category Grid */}
            <div className="space-y-3">
              <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Select Category</p>
              <div className="grid grid-cols-4 gap-2.5">
                {categories.map((cat) => {
                  const isActive = category === cat.id;
                  return (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setCategory(cat.id)}
                      className={`flex flex-col items-center justify-center py-3 rounded-2xl transition-all border-2 ${
                        isActive 
                          ? 'shadow-lg scale-[1.02]' 
                          : 'bg-white border-slate-50 text-slate-400 hover:border-slate-100'
                      }`}
                      style={{ 
                        borderColor: isActive ? accentColor : undefined,
                        backgroundColor: isActive ? lightAccent : undefined,
                        color: isActive ? accentColor : undefined
                      }}
                    >
                      <span className="text-xl mb-1.5 transition-transform group-hover:scale-110">{cat.icon}</span>
                      <span className="text-[7px] font-black uppercase tracking-tighter truncate w-full px-1 text-center">{cat.id}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Context Fields */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Date</label>
                <div className="relative">
                  <input
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full bg-slate-50 border-none rounded-xl px-4 py-3.5 text-[10px] font-black text-slate-700 uppercase tracking-widest focus:ring-1 focus:ring-slate-200 outline-none"
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Memo</label>
                <input
                  type="text"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Optional note..."
                  className="w-full bg-slate-50 border-none rounded-xl px-4 py-3.5 text-[10px] font-black text-slate-700 placeholder:text-slate-300 focus:ring-1 focus:ring-slate-200 outline-none"
                />
              </div>
            </div>

            {/* Compact Professional Actions */}
            <div className="flex flex-col space-y-3 pt-6">
              <button
                type="submit"
                className="group relative w-full h-[52px] rounded-2xl flex items-center justify-center space-x-2 font-black text-white text-[11px] uppercase tracking-[0.2em] shadow-xl transition-all active:scale-[0.98] overflow-hidden"
                style={{ 
                  background: `linear-gradient(135deg, ${accentColor}, ${gradientColor})`,
                  boxShadow: `0 8px 20px -6px ${accentColor}80`
                }}
              >
                {/* Subtle Shimmer */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:animate-[shimmer_1.5s_infinite]"></div>
                
                <svg className="w-4 h-4 text-white/90" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  {editingTransaction ? (
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                  ) : (
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                  )}
                </svg>
                <span>{editingTransaction ? 'Confirm Update' : `Save ${type === 'INCOME' ? 'Income' : 'Expense'}`}</span>
              </button>
              
              <button 
                onClick={onCancel} 
                type="button" 
                className="w-full py-3 rounded-xl text-slate-400 font-black text-[9px] uppercase tracking-widest hover:text-slate-600 hover:bg-slate-50 transition-all active:scale-95"
              >
                Discard Changes
              </button>
            </div>
          </form>
        </div>
      </div>
      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes shimmer {
          100% { transform: translateX(100%); }
        }
      `}} />
    </div>
  );
};

export default TransactionForm;

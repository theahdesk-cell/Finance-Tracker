
import React, { useRef } from 'react';
import { UserProfile, Transaction } from '../types';
import { convertToCSV, parseCSV } from '../utils';

interface SettingsProps {
  profile: UserProfile;
  setProfile: React.Dispatch<React.SetStateAction<UserProfile>>;
  savingsGoal: number;
  setSavingsGoal: React.Dispatch<React.SetStateAction<number>>;
  transactions: Transaction[];
  setTransactions: React.Dispatch<React.SetStateAction<Transaction[]>>;
}

const Settings: React.FC<SettingsProps> = ({ 
  profile, 
  setProfile, 
  savingsGoal, 
  setSavingsGoal,
  transactions,
  setTransactions
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleExport = () => {
    const csv = convertToCSV(transactions);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `takatracker_backup_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const imported = parseCSV(text);
      if (imported.length > 0) {
        if (window.confirm(`Found ${imported.length} transactions. Merge with existing data? (Cancel will overwrite)`)) {
          setTransactions(prev => [...imported, ...prev]);
        } else {
          setTransactions(imported);
        }
      } else {
        alert('No valid transactions found in file.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6 pb-20">
      <header className="px-1">
        <h1 className="text-xl font-black text-slate-800 tracking-tight">Configuration</h1>
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">App & Account Settings</p>
      </header>

      {/* User Profile Section */}
      <section className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-4">
        <div className="flex items-center space-x-4 mb-2">
          <div className="w-16 h-16 rounded-full bg-emerald-50 flex items-center justify-center text-3xl shadow-inner border-2 border-emerald-100 overflow-hidden">
            {profile.avatar ? (
              <img src={profile.avatar} alt="Avatar" className="w-full h-full object-cover" />
            ) : (
              '👤'
            )}
          </div>
          <div>
            <h2 className="text-base font-black text-slate-800">{profile.name || 'User'}</h2>
            <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{profile.email || 'No email set'}</p>
          </div>
        </div>

        <div className="space-y-3">
          <div className="space-y-1">
            <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Display Name</label>
            <input 
              type="text" 
              value={profile.name}
              onChange={(e) => setProfile(prev => ({ ...prev, name: e.target.value }))}
              className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 text-[11px] font-black text-slate-700 outline-none focus:ring-1 focus:ring-emerald-400"
            />
          </div>
          <div className="space-y-1">
            <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Email</label>
            <input 
              type="email" 
              value={profile.email}
              onChange={(e) => setProfile(prev => ({ ...prev, email: e.target.value }))}
              className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 text-[11px] font-black text-slate-700 outline-none focus:ring-1 focus:ring-emerald-400"
            />
          </div>
        </div>
      </section>

      {/* Savings Targets */}
      <section className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-[10px] font-black text-slate-800 uppercase tracking-widest">Financial Targets</h3>
          <span className="text-xs">🎯</span>
        </div>
        <div className="space-y-1">
          <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Monthly Savings Goal (৳)</label>
          <input 
            type="number" 
            value={savingsGoal}
            onChange={(e) => setSavingsGoal(parseFloat(e.target.value) || 0)}
            className="w-full bg-slate-50 border-none rounded-xl px-4 py-4 text-xl font-black text-[#006a4e] outline-none focus:ring-1 focus:ring-emerald-400"
          />
        </div>
      </section>

      {/* Backup and Restore */}
      <section className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-4">
        <h3 className="text-[10px] font-black text-slate-800 uppercase tracking-widest mb-2">Data Management</h3>
        
        <div className="grid grid-cols-2 gap-3">
          <button 
            onClick={handleExport}
            className="flex flex-col items-center justify-center p-4 bg-emerald-50 rounded-2xl border border-emerald-100 hover:bg-emerald-100 transition-colors group"
          >
            <svg className="w-5 h-5 text-emerald-600 mb-2 group-hover:scale-110 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4 16v1a2 2 0 002 2h12a2 2 0 002-2v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
            </svg>
            <span className="text-[8px] font-black text-emerald-700 uppercase tracking-widest">Export CSV</span>
          </button>

          <button 
            onClick={() => fileInputRef.current?.click()}
            className="flex flex-col items-center justify-center p-4 bg-slate-50 rounded-2xl border border-slate-100 hover:bg-slate-100 transition-colors group"
          >
            <svg className="w-5 h-5 text-slate-400 mb-2 group-hover:scale-110 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4 16v1a2 2 0 002 2h12a2 2 0 002-2v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
            </svg>
            <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Import CSV</span>
          </button>
        </div>
        <input 
          type="file" 
          ref={fileInputRef} 
          onChange={handleImport} 
          accept=".csv" 
          className="hidden" 
        />
        
        <button 
          onClick={() => {
            if(window.confirm('Erase all transactions and settings? This is permanent.')) {
              setTransactions([]);
              localStorage.clear();
              window.location.reload();
            }
          }}
          className="w-full py-3 text-[8px] font-black text-rose-500 uppercase tracking-widest hover:bg-rose-50 rounded-xl transition-colors"
        >
          Reset Application Data
        </button>
      </section>

      {/* Links and Credits */}
      <section className="bg-slate-900 rounded-3xl p-6 text-white space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-[9px] font-black text-emerald-400 uppercase tracking-[0.2em]">Resources</h3>
          <span className="text-[8px] font-black bg-white/10 px-2 py-0.5 rounded-full text-white/50">v1.5.0</span>
        </div>
        
        <a 
          href="https://www.coreprompting.com/" 
          target="_blank" 
          rel="noopener noreferrer"
          className="flex items-center justify-between p-3 bg-white/5 rounded-xl hover:bg-white/10 transition-colors"
        >
          <div className="flex items-center space-x-3">
            <span className="text-base">🚀</span>
            <span className="text-[10px] font-black uppercase tracking-widest">Visit CorePrompting</span>
          </div>
          <svg className="w-3 h-3 text-emerald-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M14 5l7 7m0 0l-7 7m7-7H3" />
          </svg>
        </a>

        <div className="pt-2 text-center">
          <p className="text-[7px] font-black text-white/30 uppercase tracking-[0.3em] leading-relaxed">
            Crafted for Financial Excellence<br/>
            Sponsored by <a href="https://Facebook.com/dealsbdonline" target="_blank" rel="noopener noreferrer" className="text-emerald-400 hover:text-emerald-300 hover:underline transition-all">@Deals BD</a>
          </p>
        </div>
      </section>
    </div>
  );
};

export default Settings;


import { ExpenseCategory, IncomeSource } from './types';

export const CURRENCY = '৳';

export const EXPENSE_CATEGORIES = [
  { id: ExpenseCategory.FOOD, color: '#f42a41', icon: '🍔' }, // Flag Red
  { id: ExpenseCategory.WORK, color: '#006a4e', icon: '💼' }, // Flag Green
  { id: ExpenseCategory.TRANSPORT, color: '#f59e0b', icon: '🚗' },
  { id: ExpenseCategory.RENT, color: '#ef4444', icon: '🏠' },
  { id: ExpenseCategory.SHOPPING, color: '#ec4899', icon: '🛍️' },
  { id: ExpenseCategory.PERSONAL, color: '#10b981', icon: '✨' },
  { id: ExpenseCategory.OTHERS, color: '#64748b', icon: '📦' },
];

export const INCOME_SOURCES = [
  { id: IncomeSource.SALARY, color: '#006a4e', icon: '💰' }, // Flag Green
  { id: IncomeSource.BUSINESS, color: '#065f46', icon: '🏢' },
  { id: IncomeSource.FREELANCE, color: '#047857', icon: '💻' },
  { id: IncomeSource.OTHER, color: '#064e3b', icon: '➕' },
];

export const STORAGE_KEY = 'takatracker_data_v1';
export const SETTINGS_STORAGE_KEY = 'takatracker_settings_v1';
export const PROFILE_STORAGE_KEY = 'willbe_profile_v1';
